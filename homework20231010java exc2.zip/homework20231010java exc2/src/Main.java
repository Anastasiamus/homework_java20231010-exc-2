import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите суммарную стоимость покупок: ");
        int a = scanner.nextInt();
        System.out.println("Введите сумму денег: ");
        int b = scanner.nextInt();
        System.out.println(a<b);
        int сдача = b-a;
        int рублей = (int) сдача;
        int копеек = (int) Math.ceil((сдача-рублей)*100);
        System.out.printf("Сумма сдачи: %d рублей и %d копеек" , рублей, копеек );






    }
}

//2 Пользователь-продавец вводит суммарную стоимость покупок и сумму денег,
// которую дал покупатель.
// Выведите сумму сдачи в виде “X рублей и Y копеек”.